biobeam - GPU accelerated simulation of light interacting with tissue
=====================================================================





The full documentation with examples can be found `here <https://maweigert.github.io/biobeam/>`_.